package thym.app.model;

public enum Role {
	USER,ADMIN,GUEST

}
