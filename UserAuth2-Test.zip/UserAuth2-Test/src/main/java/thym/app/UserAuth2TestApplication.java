package thym.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserAuth2TestApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserAuth2TestApplication.class, args);
	}
}
