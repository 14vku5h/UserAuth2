package com.demo.bind;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeBindingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymeBindingAppApplication.class, args);
	}
}
