package com.demo.bind.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.demo.bind.model.Greeting;

@Controller
	public class GreetingController {
	public static final Logger logger=LoggerFactory.getLogger("GreetingController.class");
	
	 	
	    @GetMapping("/greeting")
	    public  ModelAndView greetingForm() {
	    	//logger.info("in greeting");
	    	ModelAndView mv=new ModelAndView("greeting");
	    	Greeting g = new Greeting();
	    	
	        mv.addObject("greeting", g);
	        return mv;
	    }

	    @PostMapping("/greeting")
	    public ModelAndView greetingSubmit(Greeting greeting,BindingResult result) {
	    	if(result.hasErrors()) {
	    		ModelAndView mv=new ModelAndView("greeting");
		        return mv;
	    	}
	    	
	    	ModelAndView mv=new ModelAndView("result");
	    	mv.addObject("greeting", greeting);
	        return mv;
	    }

	}

